package com.example.remotecamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private var server: CameraHttpServer? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var poller: java.util.concurrent.ScheduledExecutorService? = null

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.CAMERA] == true) cameraMode() else toast("Camera permission လိုအပ်ပါတယ်")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            setBackgroundColor(0xFF070B16.toInt())
        }
        setContentView(ScrollView(this).apply { addView(root) })
        home()
    }

    private fun home() {
        stopEverything()
        root.removeAllViews()
        header("CONNECT  •  CONTROL  •  CAPTURE")
        label("Choose your device role", 16, Color.WHITE, true)
        button("📷   CAMERA DEVICE", "This phone takes photos and videos", 0xFF075FCB.toInt()) { requestCamera() }
        button("🎮   REMOTE CONTROLLER", "Control the other phone over hotspot", 0xFF5533B8.toInt()) { controllerSetup() }
        note("No internet required. Connect both phones to the same mobile hotspot first.")
        note("Live preview is completely disabled in this version.")
    }

    private fun requestCamera() {
        val p = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) cameraMode()
        else permissionRequest.launch(p)
    }

    private fun cameraMode() {
        root.removeAllViews()
        header("CAMERA DEVICE")
        val status = statusCard("STARTING", "Preparing local camera service", 0xFFFFB02E.toInt())
        root.addView(status)
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, imageCapture, videoCapture)
            } catch (e: Exception) { runOnUiThread { toast("Camera error: ${e.message}") } }
        }, ContextCompat.getMainExecutor(this))

        val ip = localIp()
        try {
            server = CameraHttpServer(8787,
                onCapture = { runOnUiThread { takePhoto() } },
                onStartVideo = { runOnUiThread { startVideo() } },
                onStopVideo = { runOnUiThread { stopVideo() } }
            ).also { it.start(5000, false) }
            updateStatus(status, "READY • WAITING", "Controller address: $ip:8787", 0xFF21D477.toInt())
        } catch (e: Exception) {
            updateStatus(status, "SERVICE ERROR", e.message ?: "Could not start server", 0xFFFF5252.toInt())
        }
        label("CONNECTION DETAILS", 13, 0xFF16B8FF.toInt(), true)
        info("IP ADDRESS", ip)
        info("PORT", "8787")
        note("Keep this screen open and keep the camera phone awake.")
        button("⏹   STOP CAMERA SERVICE", "Disconnect controller", 0xFF9D2735.toInt()) { home() }
    }

    private fun takePhoto() {
        val cap = imageCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KChoRemoteCamera")
        }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        cap.takePicture(output, ContextCompat.getMainExecutor(this), object: ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { toast("Photo saved on camera phone") }
            override fun onError(e: ImageCaptureException) { toast("Photo failed: ${e.message}") }
        })
    }

    private fun startVideo() {
        if (recording != null) return
        val cap = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KChoRemoteCamera")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        recording = cap.output.prepareRecording(this, output).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    recording = null
                    toast(if (event.hasError()) "Video error" else "Video saved on camera phone")
                }
            }
    }

    private fun stopVideo() { recording?.stop() }

    private fun controllerSetup() {
        root.removeAllViews()
        header("REMOTE CONTROLLER")
        note("Join the same mobile hotspot as the camera phone. Enter the IP address shown on its screen.")
        val input = EditText(this).apply {
            hint = "Camera IP e.g. 192.168.43.1"; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(0xFF8B9AB4.toInt())
            setPadding(dp(14), dp(13), dp(14), dp(13)); setBackgroundColor(0xFF17243A.toInt())
            setText("192.168.43.1")
        }
        root.addView(input, LinearLayout.LayoutParams(-1,-2))
        button("🔗   CONNECT DEVICE", "Check connection", 0xFF075FCB.toInt()) {
            val ip = input.text.toString().trim()
            Thread {
                val ok = runCatching { HttpClient.get("http://$ip:8787/status").toString(Charsets.UTF_8).contains("READY") }.getOrDefault(false)
                runOnUiThread { if (ok) remote(ip) else toast("Not connected. Check IP and hotspot.") }
            }.start()
        }
        button("←   BACK", "Return to home", 0xFF35445D.toInt()) { home() }
    }

    private fun remote(ip: String) {
        root.removeAllViews()
        header("REMOTE CONTROLLER")
        val status = statusCard("CONNECTED", "Camera device • $ip", 0xFF21D477.toInt())
        root.addView(status)
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            val ok = runCatching { HttpClient.get("http://$ip:8787/status").toString(Charsets.UTF_8).contains("READY") }.getOrDefault(false)
            runOnUiThread { updateStatus(status, if (ok) "CONNECTED" else "DISCONNECTED",
                if (ok) "Camera device • $ip" else "Connection lost • check hotspot",
                if (ok) 0xFF21D477.toInt() else 0xFFFF5252.toInt()) }
        }, 2, 3, java.util.concurrent.TimeUnit.SECONDS)
        label("CAMERA CONTROLS", 14, 0xFF16B8FF.toInt(), true)
        button("📸   TAKE PHOTO", "Capture one photo", 0xFF075FCB.toInt()) { command(ip, "capture") }
        button("⏺   START VIDEO", "Start recording on camera phone", 0xFFB32635.toInt()) { command(ip, "video/start") }
        button("⏹   STOP VIDEO", "Stop and save video", 0xFF9A5B08.toInt()) { command(ip, "video/stop") }
        note("Files are saved on the camera phone. Video is not streamed to this phone.")
        button("DISCONNECT", "Close remote connection", 0xFF35445D.toInt()) { home() }
    }

    private fun command(ip: String, cmd: String) {
        Thread {
            val ok = runCatching { HttpClient.get("http://$ip:8787/$cmd"); true }.getOrDefault(false)
            runOnUiThread { toast(if (ok) "Command sent" else "Connection failed") }
        }.start()
    }

    private fun header(sub: String) {
        label("◉  K'Cho", 28, Color.WHITE, true)
        label("RemoteCamera", 24, 0xFF16B8FF.toInt(), true)
        label(sub, 10, 0xFF8DBBFF.toInt(), true)
        val line = View(this).apply { setBackgroundColor(0xFF123B68.toInt()) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        space(14)
    }
    private fun button(title: String, desc: String, color: Int, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(15),dp(16),dp(15))
            setBackgroundColor(color); isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        box.addView(TextView(this).apply { text=title; textSize=17f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD })
        box.addView(TextView(this).apply { text=desc; textSize=12f; setTextColor(0xFFE3EEFF.toInt()); setPadding(0,dp(4),0,0) })
        root.addView(box, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
    }
    private fun statusCard(t:String,d:String,c:Int)=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); setBackgroundColor(0xFF14243A.toInt())
        addView(TextView(this@MainActivity).apply { text="●  $t"; textSize=17f; setTextColor(c); tag="t"; typeface=android.graphics.Typeface.DEFAULT_BOLD })
        addView(TextView(this@MainActivity).apply { text=d; textSize=12f; setTextColor(0xFFD4E0F2.toInt()); tag="d"; setPadding(0,dp(5),0,0) })
    }
    private fun updateStatus(v:LinearLayout,t:String,d:String,c:Int) {
        v.findViewWithTag<TextView>("t")?.apply { text="●  $t"; setTextColor(c) }
        v.findViewWithTag<TextView>("d")?.text=d
    }
    private fun info(k:String,v:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(10)); setBackgroundColor(0xFF14243A.toInt()) }
        box.addView(TextView(this).apply { text=k; textSize=10f; setTextColor(0xFF8CA7C8.toInt()) })
        box.addView(TextView(this).apply { text=v; textSize=18f; setTextColor(Color.WHITE) })
        root.addView(box, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
    }
    private fun label(s:String,sz:Int,c:Int,b:Boolean=false) { root.addView(TextView(this).apply { text=s; textSize=sz.toFloat(); setTextColor(c); if(b) typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,dp(4),0,dp(5)) }) }
    private fun note(s:String) = label(s,12,0xFF9AABC4.toInt())
    private fun space(n:Int) { root.addView(View(this),LinearLayout.LayoutParams(1,dp(n))) }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun localIp():String {
        try {
            val ns=NetworkInterface.getNetworkInterfaces()
            while(ns.hasMoreElements()) { val addrs=ns.nextElement().inetAddresses
                while(addrs.hasMoreElements()) { val a=addrs.nextElement(); val ip=a.hostAddress ?: continue
                    if(!a.isLoopbackAddress && a is Inet4Address && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) return ip
                }
            }
        } catch(_:Exception) {}
        return "IP not found - check hotspot"
    }
    private fun stopEverything() { poller?.shutdownNow(); poller=null; server?.stop(); server=null; recording?.stop(); recording=null }
    override fun onDestroy() { stopEverything(); super.onDestroy() }
}
