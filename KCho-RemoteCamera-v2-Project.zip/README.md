# K'Cho RemoteCamera v2.0

- Live preview removed entirely.
- Remote photo capture and remote video start/stop.
- Connected / Disconnected indicator and camera phone IP display.
- Works over a shared mobile hotspot without internet.
- Photos saved in Pictures/KChoRemoteCamera; videos in Movies/KChoRemoteCamera.

## Build
Upload all files to GitHub. Keep `.github/workflows/android.yml` in place. Push to main/master or run the workflow manually. Download the `KCho-RemoteCamera-debug-apk` artifact.

## Use
1. Install the APK on both Android phones.
2. Enable hotspot on one phone; connect the other phone to it. No internet/data plan needed for local communication.
3. On the phone acting as camera, open CAMERA DEVICE and grant camera/microphone permissions. Keep the app open.
4. On the controller phone, choose REMOTE CONTROLLER, enter the IP shown by the camera phone, then Connect.
5. Use Take Photo, Start Video and Stop Video. Files stay on the camera phone.

Local HTTP on port 8787 has no authentication or encryption. Use only on your trusted private hotspot. Android hotspot routing varies by device; test on your phones. Keep camera app in foreground.
