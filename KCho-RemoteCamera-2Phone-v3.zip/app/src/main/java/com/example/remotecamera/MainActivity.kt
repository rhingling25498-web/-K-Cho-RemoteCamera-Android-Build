package com.example.remotecamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private var server: CameraHttpServer? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var poller: java.util.concurrent.ScheduledExecutorService? = null
    private var currentMode = "PHOTO"

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) cameraMode()
        else toast("Camera permission လိုအပ်ပါတယ်")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(BG)
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        home()
    }

    private fun home() {
        stopEverything(); root.removeAllViews()
        header("REMOTE CAMERA CONTROL")
        card {
            label("သင့်ဖုန်း၏ လုပ်ဆောင်ချက်ကို ရွေးပါ", 17, Color.WHITE, true)
            label("ဖုန်း ၂ လုံးတည်း • အင်တာနက်မလို • ဖိုင်ပို့စရာမလို", 12, MUTED)
        }
        space(14)
        actionButton("📷  CAMERA PHONE", "ဒီဖုန်းက ဓာတ်ပုံ / ဗီဒီယို ရိုက်ကူးမယ်", BLUE) { requestCamera() }
        actionButton("🎮  REMOTE CONTROLLER", "တခြားဖုန်းကို ခလုတ်နဲ့ ထိန်းချုပ်မယ်", PURPLE) { controllerSetup() }
        space(8)
        label("အသုံးပြုပုံ", 14, CYAN, true)
        label("၁။ Camera ဖုန်းမှာ Hotspot ဖွင့်ပါ။\n၂။ Controller ဖုန်းကို အဲဒီ Hotspot ချိတ်ပါ။\n၃။ ဖုန်းနှစ်လုံးစလုံးမှာ ဒီ APK ကိုဖွင့်ပြီး Mode ရွေးပါ။", 13, MUTED)
    }

    private fun requestCamera() {
        val p = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) cameraMode()
        else permissionRequest.launch(p)
    }

    private fun cameraMode() {
        root.removeAllViews(); header("CAMERA PHONE")
        val status = statusCard("STARTING CAMERA", "Camera ပြင်ဆင်နေပါတယ်", AMBER); root.addView(status)
        label("ဒီဖုန်းက ဓာတ်ပုံနဲ့ ဗီဒီယိုတွေကိုပဲ သိမ်းဆည်းပါမယ်။", 13, MUTED)
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, imageCapture, videoCapture)
                startLocalServer(status)
            } catch (e: Exception) {
                updateStatus(status, "CAMERA ERROR", e.message ?: "Camera ဖွင့်မရပါ", RED)
            }
        }, ContextCompat.getMainExecutor(this))
        button("STOP CAMERA SERVICE", "ဝန်ဆောင်မှုရပ်မယ်", DARK_BUTTON) { home() }
    }

    private fun startLocalServer(status: LinearLayout) {
        val ip = localIp()
        try {
            server = CameraHttpServer(8787,
                onCapture = { runOnUiThread { takePhoto() } },
                onStartVideo = { runOnUiThread { startVideo() } },
                onStopVideo = { runOnUiThread { stopVideo() } },
                onPhotoMode = { runOnUiThread { stopVideo() } }
            ).also { it.start(5000, false) }
            updateStatus(status, "READY • WAITING FOR PHONE 2", "Hotspot IP: $ip  |  Port: 8787", GREEN)
            label("CONNECTION", 13, CYAN, true)
            info("CAMERA PHONE IP", ip)
            info("PORT", "8787")
            label("ဖုန်း ၂ မှာ Controller Mode ကိုဖွင့်ပြီး Hotspot ချိတ်ပါ။", 12, MUTED)
        } catch (e: Exception) {
            updateStatus(status, "SERVICE ERROR", e.message ?: "Server စတင်မရပါ", RED)
        }
    }

    private fun takePhoto() {
        val cap = imageCapture ?: run { toast("Camera အဆင်သင့်မဖြစ်သေးပါ"); return }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KChoRemoteCamera")
        }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        cap.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { toast("ဓာတ်ပုံကို ဒီဖုန်းထဲ သိမ်းပြီးပါပြီ") }
            override fun onError(e: ImageCaptureException) { toast("Photo မရိုက်နိုင်ပါ: ${e.message}") }
        })
    }

    private fun startVideo() {
        if (recording != null) return
        val cap = videoCapture ?: run { toast("Video Camera အဆင်သင့်မဖြစ်သေးပါ"); return }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KChoRemoteCamera")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        recording = cap.output.prepareRecording(this, output).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    recording = null
                    toast(if (event.hasError()) "Video error" else "ဗီဒီယိုကို ဒီဖုန်းထဲ သိမ်းပြီးပါပြီ")
                }
            }
        toast("Video စတင်ရိုက်ကူးနေပါပြီ")
    }

    private fun stopVideo() { recording?.stop() }

    private fun controllerSetup() {
        root.removeAllViews(); header("REMOTE CONTROLLER")
        card {
            label("တူညီတဲ့ Hotspot ကို ချိတ်ထားပါ", 16, Color.WHITE, true)
            label("Camera ဖုန်းက Hotspot ဖွင့်ထားရပါမယ်။ အောက်က IP ကို အလိုအလျောက်ရှာပေးပါမယ်။", 12, MUTED)
        }
        space(12)
        val gateway = hotspotGateway()
        val input = EditText(this).apply {
            hint = "Camera IP ဥပမာ 192.168.43.1"; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(MUTED)
            setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(PANEL, 14)
            setText(gateway)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        actionButton("CONNECT TO CAMERA", "Hotspot ကတစ်ဆင့် ချိတ်ဆက်မယ်", BLUE) {
            val ip = input.text.toString().trim()
            Thread {
                val ok = runCatching { HttpClient.get("http://$ip:8787/status").toString(Charsets.UTF_8).contains("READY") }.getOrDefault(false)
                runOnUiThread { if (ok) remote(ip) else toast("မချိတ်ဆက်နိုင်ပါ။ Hotspot နဲ့ IP ကို စစ်ပါ။") }
            }.start()
        }
        label("IP အလိုအလျောက်မမှန်ပါက Camera ဖုန်းမျက်နှာပြင်ပေါ်က IP ကို ထည့်ပါ။", 12, MUTED)
        button("← BACK", "", DARK_BUTTON) { home() }
    }

    private fun remote(ip: String) {
        stopPoller(); root.removeAllViews(); currentMode = "PHOTO"; header("REMOTE CONTROLLER")
        val status = statusCard("CONNECTED", "Camera phone • $ip", GREEN); root.addView(status)
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            val ok = runCatching { HttpClient.get("http://$ip:8787/status").toString(Charsets.UTF_8).contains("READY") }.getOrDefault(false)
            runOnUiThread { updateStatus(status, if (ok) "CONNECTED" else "DISCONNECTED", if (ok) "Camera phone • $ip" else "Hotspot connection lost", if (ok) GREEN else RED) }
        }, 2, 3, TimeUnit.SECONDS)
        space(10)
        label("PHOTO CONTROL", 13, CYAN, true)
        actionButton("📸  TAKE PHOTO", "Camera ဖုန်းမှာ ဓာတ်ပုံရိုက်ပြီး အဲဒီဖုန်းထဲသိမ်းမယ်", BLUE) { command(ip, "capture") }
        space(8)
        label("VIDEO CONTROL", 13, CYAN, true)
        actionButton("●  START VIDEO", "Camera ဖုန်းမှာ ဗီဒီယိုစတင်ရိုက်မယ်", RED) { command(ip, "video/start") }
        actionButton("■  STOP VIDEO", "ဗီဒီယိုရပ်ပြီး Camera ဖုန်းထဲသိမ်းမယ်", AMBER) { command(ip, "video/stop") }
        actionButton("📷  BACK TO PHOTO MODE", "Video ရိုက်နေပါက အရင်ရပ်ပြီး Photo Mode ပြန်ထားမယ်", PURPLE) { command(ip, "mode/photo") }
        space(8)
        label("ဓာတ်ပုံ / ဗီဒီယိုဖိုင်များကို Camera ဖုန်းထဲမှာသာ သိမ်းဆည်းပါတယ်။ ဒီဖုန်းကို ဖိုင်မပို့ပါ။", 12, MUTED)
        button("DISCONNECT", "", DARK_BUTTON) { home() }
    }

    private fun command(ip: String, cmd: String) {
        Thread {
            val ok = runCatching { HttpClient.get("http://$ip:8787/$cmd"); true }.getOrDefault(false)
            runOnUiThread { toast(if (ok) "Command sent" else "ချိတ်ဆက်မှု ပြတ်တောက်နေပါတယ်") }
        }.start()
    }

    private fun header(sub: String) {
        label("K'Cho", 30, Color.WHITE, true)
        label("RemoteCamera", 22, CYAN, true)
        label(sub, 11, MUTED, true)
        val line = View(this).apply { background = rounded(0xFF20334F.toInt(), 2) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(2))); space(14)
    }
    private fun card(content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(PANEL, 18); content() }
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
    private fun actionButton(title: String, desc: String, color: Int, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(17), dp(18), dp(17)); background = rounded(color, 18)
            isClickable = true; isFocusable = true; elevation = dp(3).toFloat(); setOnClickListener { action() }
        }
        box.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.BOLD) })
        box.addView(TextView(this).apply { text = desc; textSize = 12f; setTextColor(0xFFE5EDFA.toInt()); setPadding(0, dp(5), 0, 0) })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
    }
    private fun button(title: String, desc: String, color: Int, action: () -> Unit) = actionButton(title, desc, color, action)
    private fun statusCard(t: String, d: String, c: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(PANEL, 16)
        addView(TextView(this@MainActivity).apply { text = "●  $t"; textSize = 16f; setTextColor(c); tag = "t"; typeface = Typeface.DEFAULT_BOLD })
        addView(TextView(this@MainActivity).apply { text = d; textSize = 12f; setTextColor(MUTED); tag = "d"; setPadding(0, dp(6), 0, 0) })
    }
    private fun updateStatus(v: LinearLayout, t: String, d: String, c: Int) {
        v.findViewWithTag<TextView>("t")?.apply { text = "●  $t"; setTextColor(c) }
        v.findViewWithTag<TextView>("d")?.text = d
    }
    private fun info(k: String, v: String) {
        card { label(k, 10, MUTED, true); label(v, 18, Color.WHITE, true) }
    }
    private fun label(s: String, sz: Int, c: Int, b: Boolean = false) {
        root.addView(TextView(this).apply { text = s; textSize = sz.toFloat(); setTextColor(c); if (b) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(6)) })
    }
    private fun space(n: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(n))) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hotspotGateway(): String {
        return try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val raw = wifi.dhcpInfo?.gateway ?: 0
            if (raw == 0) "192.168.43.1" else listOf(raw and 0xff, raw shr 8 and 0xff, raw shr 16 and 0xff, raw shr 24 and 0xff).joinToString(".")
        } catch (_: Exception) { "192.168.43.1" }
    }
    private fun localIp(): String {
        try {
            val ns = NetworkInterface.getNetworkInterfaces()
            while (ns.hasMoreElements()) { val addrs = ns.nextElement().inetAddresses
                while (addrs.hasMoreElements()) { val a = addrs.nextElement(); val ip = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && a is Inet4Address && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) return ip
                }
            }
        } catch (_: Exception) { }
        return "IP မတွေ့ပါ - Hotspot စစ်ပါ"
    }
    private fun stopPoller() { poller?.shutdownNow(); poller = null }
    private fun stopEverything() { stopPoller(); server?.stop(); server = null; recording?.stop(); recording = null }
    override fun onDestroy() { stopEverything(); super.onDestroy() }

    companion object {
        private val BG = 0xFF080D18.toInt()
        private val PANEL = 0xFF142238.toInt()
        private val MUTED = 0xFFAAB9CE.toInt()
        private val CYAN = 0xFF42D7FF.toInt()
        private val BLUE = 0xFF1769D2.toInt()
        private val PURPLE = 0xFF6846C8.toInt()
        private val RED = 0xFFC93648.toInt()
        private val AMBER = 0xFFAA6B16.toInt()
        private val GREEN = 0xFF20C982.toInt()
        private val DARK_BUTTON = 0xFF29384D.toInt()
    }
}
