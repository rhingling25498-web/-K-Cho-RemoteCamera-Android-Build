package com.example.remotecamera

import fi.iki.elonen.NanoHTTPD

class CameraHttpServer(
    port: Int,
    private val onCapture: () -> Unit,
    private val onStartVideo: () -> Unit,
    private val onStopVideo: () -> Unit,
    private val onPhotoMode: () -> Unit
) : NanoHTTPD(port) {
    override fun serve(session: IHTTPSession): Response = when (session.uri) {
        "/status" -> newFixedLengthResponse(Response.Status.OK, "text/plain", "READY")
        "/capture" -> { onCapture(); newFixedLengthResponse("PHOTO_COMMAND_RECEIVED") }
        "/video/start" -> { onStartVideo(); newFixedLengthResponse("VIDEO_START_RECEIVED") }
        "/video/stop" -> { onStopVideo(); newFixedLengthResponse("VIDEO_STOP_RECEIVED") }
        "/mode/photo" -> { onPhotoMode(); newFixedLengthResponse("PHOTO_MODE_SELECTED") }
        else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
    }
}
