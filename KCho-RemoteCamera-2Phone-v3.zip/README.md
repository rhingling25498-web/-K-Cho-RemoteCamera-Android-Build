# K'Cho RemoteCamera — 2 Phone Edition

## What it does
- Uses exactly two Android phones.
- Camera phone creates the mobile hotspot and runs the camera service.
- Controller phone joins that hotspot and sends photo/video commands.
- Photos and videos are saved only on the camera phone (`Pictures/KChoRemoteCamera` and `Movies/KChoRemoteCamera`).
- No file transfer and no live preview.

## Setup
1. On the camera phone, turn on Mobile Hotspot. Keep this phone connected to power if recording for a long time.
2. Install and open the APK on both phones.
3. On phone 1, choose **CAMERA PHONE** and allow Camera and Microphone permissions. Keep the app open. It will show the phone's local IP and start its local control service after the camera is ready.
4. On phone 2, join phone 1's hotspot, open the APK, choose **REMOTE CONTROLLER**, and connect. The app tries to fill in the hotspot gateway automatically. If it fails, enter the IP shown on phone 1.
5. Use **TAKE PHOTO**, **START VIDEO**, **STOP VIDEO**, or **BACK TO PHOTO MODE**.

## Build with GitHub Actions
- Upload this ZIP to the repository root.
- Keep the workflow at `.github/workflows/android.yml` (the workflow is also included in this ZIP).
- Run the workflow from the Actions tab. The workflow extracts the ZIP if the Gradle project is not already at the repository root and uploads the debug APK as an artifact.

## Notes
- Both phones must be on the same hotspot network. Internet access is not required.
- Android hotspot gateway addresses vary by device. The controller attempts to read the gateway automatically; if it cannot, use the IP displayed on the camera phone.
- Keep the camera app in the foreground. Android battery/background restrictions may stop camera access if the app is closed or the screen is aggressively managed.
- This is a local-network prototype. Use it only on a trusted hotspot; commands are not encrypted or password protected.
