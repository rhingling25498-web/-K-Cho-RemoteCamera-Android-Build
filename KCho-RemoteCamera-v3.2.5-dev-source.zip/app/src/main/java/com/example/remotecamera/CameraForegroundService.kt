package com.example.remotecamera

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.net.Inet4Address
import java.net.NetworkInterface

/** CameraX and the HTTP command server live independently from the Activity. */
class CameraForegroundService : LifecycleService() {
    inner class LocalBinder : Binder() { fun service() = this@CameraForegroundService }
    private val binder = LocalBinder()
    interface Listener {
        fun onReady(ip: String)
        fun onError(message: String)
        fun onRecordingChanged(recording: Boolean)
        fun onPhotoSaved(message: String)
    }
    @Volatile private var listener: Listener? = null
    @Volatile private var readyIp: String? = null
    @Volatile private var startupError: String? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    @Volatile private var recording: Recording? = null
    private var server: CameraHttpServer? = null
    private var bluetoothServer: BluetoothServerSocket? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Camera service", NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIFICATION_ID, NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("K'Cho RemoteCamera အလုပ်လုပ်နေသည်")
            .setContentText("Camera နှင့် Remote ချိတ်ဆက်မှု အသင့်ရှိသည်")
            .setOngoing(true).build())
        initializeCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent): IBinder { super.onBind(intent); return binder }
    fun setListener(value: Listener?) {
        listener = value
        readyIp?.let { value?.onReady(it) }
        startupError?.let { value?.onError(it) }
    }
    fun isRecordingNow() = recording != null

    fun startBluetoothServer(): String? {
        if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: return null
            if (!adapter.isEnabled) return null
            if (bluetoothServer == null) {
                bluetoothServer = BluetoothTransport.startServer(adapter) { command ->
                    when (command) {
                        "STATE" -> if (recording != null) "RECORDING" else "IDLE"
                        "CAPTURE" -> { ContextCompat.getMainExecutor(this).execute { takePhoto() }; "PHOTO_COMMAND_RECEIVED" }
                        "VIDEO_TOGGLE" -> { ContextCompat.getMainExecutor(this).execute { if (recording != null) stopVideo() else startVideo() }; "VIDEO_TOGGLE_RECEIVED" }
                        "VIDEO_START" -> { ContextCompat.getMainExecutor(this).execute { startVideo() }; "VIDEO_START_RECEIVED" }
                        "VIDEO_STOP" -> { ContextCompat.getMainExecutor(this).execute { stopVideo() }; "VIDEO_STOP_RECEIVED" }
                        "PHOTO_MODE" -> { ContextCompat.getMainExecutor(this).execute { stopVideo() }; "PHOTO_MODE_SELECTED" }
                        else -> "UNKNOWN_COMMAND"
                    }
                }
            }
            adapter.name?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }

    private fun initializeCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            startupError = "Camera permission မရှိပါ"; listener?.onError(startupError!!); stopSelf(); return
        }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, imageCapture, videoCapture)
                val ip = localIp()
                server = CameraHttpServer(8787,
                    { ContextCompat.getMainExecutor(this).execute { takePhoto() } },
                    { ContextCompat.getMainExecutor(this).execute { startVideo() } },
                    { ContextCompat.getMainExecutor(this).execute { stopVideo() } },
                    { ContextCompat.getMainExecutor(this).execute { stopVideo() } },
                    { recording != null })
                    .also { it.start(5000, false) }
                readyIp = ip; listener?.onReady(ip)
            } catch (e: Exception) { startupError = e.message ?: "Camera ဖွင့်မရပါ"; listener?.onError(startupError!!) }
        }, ContextCompat.getMainExecutor(this))
    }

    fun takePhoto() {
        val cap = imageCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KChoRemoteCamera")
        }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        cap.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) { listener?.onPhotoSaved("ဓာတ်ပုံကို ဒီဖုန်းထဲ သိမ်းပြီးပါပြီ") }
            override fun onError(error: ImageCaptureException) { listener?.onError("Photo မရိုက်နိုင်ပါ: ${error.message}") }
        })
    }

    fun startVideo() {
        if (recording != null) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listener?.onError("Microphone permission မရှိပါ"); return
        }
        val cap = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KCho_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KChoRemoteCamera")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        recording = cap.output.prepareRecording(this, output).withAudioEnabled().start(ContextCompat.getMainExecutor(this)) { event ->
            if (event is VideoRecordEvent.Finalize) {
                recording = null; listener?.onRecordingChanged(false)
                if (event.hasError()) listener?.onError("Video သိမ်းရာတွင် အမှားရှိသည်")
            }
        }
        listener?.onRecordingChanged(true)
    }
    fun stopVideo() { recording?.stop() }

    private fun localIp(): String {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            val candidates = mutableListOf<Pair<Boolean, String>>()
            while (interfaces.hasMoreElements()) {
                val network = interfaces.nextElement()
                if (!runCatching { network.isUp && !network.isLoopback }.getOrDefault(false)) continue
                val name = network.name.lowercase()
                val wifiOrHotspot = name.startsWith("wlan") || name.startsWith("swlan") || name.startsWith("ap") || name.startsWith("softap") || name.contains("wifi")
                val addresses = network.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    val host = address.hostAddress ?: continue
                    if (!address.isLoopbackAddress && address is Inet4Address &&
                        (host.startsWith("192.168.") || host.startsWith("10.") || host.startsWith("172."))) {
                        candidates.add(wifiOrHotspot to host)
                    }
                }
            }
            candidates.firstOrNull { it.first }?.second ?: candidates.firstOrNull()?.second ?: "IP မတွေ့ပါ - Hotspot စစ်ပါ"
        } catch (_: Exception) { "IP မတွေ့ပါ - Hotspot စစ်ပါ" }
    }
    override fun onDestroy() {
        server?.stop(); server = null; runCatching { bluetoothServer?.close() }; bluetoothServer = null; BluetoothTransport.resetConnection(); recording?.stop(); recording = null
        runCatching { ProcessCameraProvider.getInstance(this).get().unbindAll() }
        super.onDestroy()
    }
    companion object { const val CHANNEL = "kcho_camera_service"; const val NOTIFICATION_ID = 732 }
}
