package com.example.remotecamera

import fi.iki.elonen.NanoHTTPD
import java.util.concurrent.atomic.AtomicBoolean

class CameraHttpServer(
    port: Int,
    private val onCapture: () -> Unit,
    private val onStartVideo: () -> Unit,
    private val onStopVideo: () -> Unit,
    private val onPhotoMode: () -> Unit,
    private val isRecording: () -> Boolean
) : NanoHTTPD(port) {
    private val controllerConnected = AtomicBoolean(false)
    private fun isControllerConnected(): Boolean = controllerConnected.get()

    override fun serve(session: IHTTPSession): Response = when (session.uri) {
        "/status" -> newFixedLengthResponse(Response.Status.OK, "text/plain", "READY")
        "/connection" -> newFixedLengthResponse(Response.Status.OK, "text/plain", if (isControllerConnected()) "CONNECTED" else "DISCONNECTED")
        "/connect" -> {
            controllerConnected.set(true)
            newFixedLengthResponse(Response.Status.OK, "text/plain", "CONNECTED")
        }
        "/disconnect" -> {
            controllerConnected.set(false)
            newFixedLengthResponse(Response.Status.OK, "text/plain", "DISCONNECTED")
        }
        "/state" -> newFixedLengthResponse(Response.Status.OK, "text/plain", if (isRecording()) "RECORDING" else "IDLE")
        "/capture" -> {
            if (!isControllerConnected()) newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "NOT_CONNECTED")
            else { onCapture(); newFixedLengthResponse("PHOTO_COMMAND_RECEIVED") }
        }
        "/video/start" -> {
            if (!isControllerConnected()) newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "NOT_CONNECTED")
            else { onStartVideo(); newFixedLengthResponse("VIDEO_START_RECEIVED") }
        }
        "/video/stop" -> {
            if (!isControllerConnected()) newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "NOT_CONNECTED")
            else { onStopVideo(); newFixedLengthResponse("VIDEO_STOP_RECEIVED") }
        }
        "/video/toggle" -> {
            if (!isControllerConnected()) newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "NOT_CONNECTED")
            else {
                if (isRecording()) onStopVideo() else onStartVideo()
                newFixedLengthResponse("VIDEO_TOGGLE_RECEIVED")
            }
        }
        "/mode/photo" -> {
            if (!isControllerConnected()) newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "NOT_CONNECTED")
            else { onPhotoMode(); newFixedLengthResponse("PHOTO_MODE_SELECTED") }
        }
        else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
    }
}
