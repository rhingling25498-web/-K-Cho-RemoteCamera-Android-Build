package com.example.remotecamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.content.pm.PackageManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Bitmap
import android.util.Base64
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private var cameraService: CameraForegroundService? = null
    private var cameraServiceBound = false
    private var cameraStatusView: LinearLayout? = null
    private val cameraConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            cameraService = (binder as? CameraForegroundService.LocalBinder)?.service()
            cameraService?.setListener(object : CameraForegroundService.Listener {
                override fun onReady(ip: String) {
                    runOnUiThread {
                        val validIp = ip.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}"))
                        cameraIp = if (validIp) ip else ""
                        if (validIp) {
                            cameraStatusView?.let { updateStatus(it, "READY • WAITING FOR PHONE 2", "Hotspot IP: $ip  |  Port: 8787", GREEN) }
                            qrImage?.setImageBitmap(makeQr("KCHO_REMOTE|HTTP|$ip|8787"))
                        } else {
                            cameraStatusView?.let { updateStatus(it, "CAMERA READY • NETWORK IP NOT FOUND", "Hotspot / Wi-Fi ကို စစ်ဆေးပါ", AMBER) }
                            qrImage?.setImageDrawable(null)
                        }
                    }
                }
                override fun onError(message: String) { runOnUiThread { cameraStatusView?.let { updateStatus(it, "CAMERA ERROR", message, RED) }; toast(message) } }
                override fun onRecordingChanged(recording: Boolean) { runOnUiThread { if (recording) setVideoButtonRecording() else setVideoButtonIdle() } }
                override fun onPhotoSaved(message: String) { runOnUiThread { toast(message) } }
            })
        }
        override fun onServiceDisconnected(name: ComponentName?) { cameraService = null }
    }
    private var cameraVideoButton: LinearLayout? = null
    private var poller: java.util.concurrent.ScheduledExecutorService? = null
    private var currentMode = "PHOTO"
    private var qrImage: ImageView? = null
    private var cameraIp: String = ""
    private var pendingBluetoothName: String? = null
    private var bluetoothDiscoveryReceiver: BroadcastReceiver? = null
    private var pendingCameraBluetoothSetup = false
    private var pendingOverlayIp: String? = null
    @Volatile private var linkAvailable = false
    private val overlayPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val ip = pendingOverlayIp
        if (ip != null && Settings.canDrawOverlays(this)) startOverlayService(ip)
        else toast("Floating Popup အသုံးပြုရန် Display over other apps Permission ကို ဖွင့်ပေးပါ")
    }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true && result[Manifest.permission.RECORD_AUDIO] == true) cameraMode()
        else toast("Camera နဲ့ Microphone permission နှစ်ခုလုံး လိုအပ်ပါတယ်")
    }
    private val bluetoothPermissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) {
            val name = pendingBluetoothName
            pendingBluetoothName = null
            if (name != null) findBluetoothDevice(name)
            else if (pendingCameraBluetoothSetup) { pendingCameraBluetoothSetup = false; requestBluetoothQr() }
        } else { pendingBluetoothName = null; pendingCameraBluetoothSetup = false; toast("Bluetooth Permission လိုအပ်ပါတယ်") }
    }
    private val bluetoothEnableRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val name = pendingBluetoothName
            pendingBluetoothName = null
            if (name != null) findBluetoothDevice(name) else requestBluetoothQr()
        } else { pendingBluetoothName = null; toast("Bluetooth ကို ဖွင့်ပေးပါ") }
    }
    private val bluetoothDiscoverableRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode > 0) enableBluetoothQr() else toast("Bluetooth discoverable ခွင့်ပြုချက် လိုအပ်ပါတယ်")
    }
    private val qrScannerLauncher = registerForActivityResult(ScanContract()) { result ->
        handleScannedQr(result.contents)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(BG)
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        home()
    }

    private fun home() {
        stopBluetoothDiscovery()
        stopService(Intent(this, OverlayControllerService::class.java)); pendingOverlayIp = null
        stopEverything(); cameraVideoButton = null; qrImage = null; root.removeAllViews()
        header("REMOTE CAMERA CONTROL")
        card {
            label("သင့်ဖုန်း၏ လုပ်ဆောင်ချက်ကို ရွေးပါ", 17, Color.WHITE, true)
            label("Camera ဖုန်း သို့မဟုတ် Remote Controller ကို ရွေးချယ်ပါ။", 12, MUTED)
        }
        space(14)
        actionButton("📷  CAMERA PHONE", "ဒီဖုန်းက ဓာတ်ပုံ / ဗီဒီယို ရိုက်ကူးမယ်", BLUE) { requestCamera() }
        actionButton("🎮  REMOTE CONTROLLER", "တခြားဖုန်းကို ခလုတ်နဲ့ ထိန်းချုပ်မယ်", PURPLE) { controllerSetup() }
        space(8)
        label("အသုံးပြုပုံ", 14, CYAN, true)
        label("၁။ Camera ဖုန်းမှာ Camera Phone ကို ရွေးပါ။\n၂။ Hotspot သို့မဟုတ် Bluetooth QR ကို ရွေးပါ။\n၃။ Controller ဖုန်းမှာ Remote Controller ကိုရွေးပြီး QR Scan လုပ်ပါ။", 13, MUTED)
    }

    private fun requestCamera() {
        val p = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) cameraMode()
        else permissionRequest.launch(p)
    }

    private fun cameraMode() {
        root.removeAllViews(); header("CAMERA PHONE")
        cameraStatusView = statusCard("STARTING CAMERA", "Camera service ပြင်ဆင်နေပါတယ်", AMBER)
        root.addView(cameraStatusView)
        label("CONTROLLER ဖုန်းဖြင့် QR ကို Scan လုပ်ပါ", 13, CYAN, true)
        qrImage = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(Color.WHITE, 18) }
        root.addView(qrImage, LinearLayout.LayoutParams(dp(230), dp(230)).apply { gravity = Gravity.CENTER; topMargin = dp(8); bottomMargin = dp(12) })
        actionButton("HOTSPOT QR", "ဖုန်းနှစ်လုံး Hotspot တစ်ခုတည်းချိတ်ပြီး QR ပြပါ", BLUE) {
            if (cameraIp.isBlank()) toast("Camera service အဆင်သင့်ဖြစ်ရန် ခဏစောင့်ပါ")
            else {
                qrImage?.setImageBitmap(makeQr("KCHO_REMOTE|HTTP|$cameraIp|8787"))
                cameraStatusView?.let { updateStatus(it, "HOTSPOT READY", "Camera IP: $cameraIp  |  Port: 8787", GREEN) }
            }
        }
        actionButton("BLUETOOTH QR", "Bluetooth မှတစ်ဆင့် ချိတ်ဆက်ရန်", PURPLE) { requestBluetoothQr() }
        label("ဒီဖုန်းက ဓာတ်ပုံနဲ့ ဗီဒီယိုတွေကိုပဲ သိမ်းဆည်းပါမယ်။", 13, MUTED)
        cameraVideoButton = actionButton("▶  START VIDEO", "ထပ်နှိပ်လျှင် ရိုက်ကူးမှုရပ်မယ်", RED) {
            val service = cameraService
            if (service == null) toast("Camera service အဆင်သင့်မဖြစ်သေးပါ")
            else if (service.isRecordingNow()) service.stopVideo() else service.startVideo()
        }
        val intent = Intent(this, CameraForegroundService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, intent) else startService(intent)
        if (!cameraServiceBound) cameraServiceBound = bindService(intent, cameraConnection, Context.BIND_AUTO_CREATE)
        button("STOP CAMERA SERVICE", "ဝန်ဆောင်မှုရပ်မယ်", DARK_BUTTON) {
            cameraService?.setListener(null)
            stopService(intent)
            if (cameraServiceBound) { unbindService(cameraConnection); cameraServiceBound = false }
            cameraService = null
            home()
        }
    }

    private fun setVideoButtonRecording() {
        cameraVideoButton?.let { b ->
            (b.getChildAt(0) as? TextView)?.text = "●  RECORDING VIDEO"
            b.background = rounded(0xFF8E2432.toInt(), 18)
        }
    }

    private fun setVideoButtonIdle() {
        cameraVideoButton?.let { b ->
            (b.getChildAt(0) as? TextView)?.text = "▶  START VIDEO"
            b.background = rounded(RED, 18)
        }
    }

    private fun requestBluetoothQr() {
        if (Build.VERSION.SDK_INT >= 31) {
            val required = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
            if (required.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
                pendingCameraBluetoothSetup = true
                bluetoothPermissionRequest.launch(required); return
            }
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("ဒီဖုန်းတွင် Bluetooth မပါဝင်ပါ"); return }
        if (!adapter.isEnabled) { bluetoothEnableRequest.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        bluetoothDiscoverableRequest.launch(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
    }

    private fun enableBluetoothQr() {
        val deviceName = cameraService?.startBluetoothServer()
        if (deviceName.isNullOrBlank()) { toast("Bluetooth Server မစတင်နိုင်ပါ။ Camera service နှင့် Bluetooth ကို စစ်ပါ။"); return }
        val encodedName = Base64.encodeToString(deviceName.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        qrImage?.setImageBitmap(makeQr("KCHO_REMOTE|BT|$encodedName|${BluetoothTransport.SERVICE_UUID}"))
        cameraStatusView?.let { updateStatus(it, "BLUETOOTH READY", "Bluetooth • $deviceName", GREEN) }
    }

    private fun controllerSetup() {
        cameraVideoButton = null; root.removeAllViews(); header("REMOTE CONTROLLER")
        card {
            label("QR ဖြင့် Camera ဖုန်းကို ချိတ်ဆက်ပါ", 16, Color.WHITE, true)
            label("Camera ဖုန်းပေါ်က QR ကို Scan လုပ်ပါ။ QR ထဲက connection mode အလိုက် Hotspot သို့မဟုတ် Bluetooth နဲ့ ချိတ်ဆက်ပေးပါမယ်။", 12, MUTED)
        }
        space(12)
        actionButton("▦  SCAN CAMERA QR", "Camera ဖုန်းပေါ်က QR ကို Scan လုပ်မယ်", BLUE) {
            val options = ScanOptions().apply {
                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                setPrompt("K'Cho RemoteCamera QR ကို Scan လုပ်ပါ")
                setBeepEnabled(false)
                setOrientationLocked(false)
            }
            qrScannerLauncher.launch(options)
        }
        label("သို့မဟုတ် Camera IP ကို ကိုယ်တိုင်ထည့်ပါ", 13, CYAN, true)
        val gateway = hotspotGateway()
        val input = EditText(this).apply {
            hint = "Camera IP ဥပမာ 192.168.43.1"; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(MUTED)
            setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(PANEL, 14)
            setText(gateway)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        actionButton("CONNECT TO CAMERA", "Hotspot ကတစ်ဆင့် ချိတ်ဆက်မယ်", BLUE) { connectHttp(input.text.toString().trim()) }
        button("← BACK", "", DARK_BUTTON) { home() }
    }

    private fun connectHttp(ip: String) {
        if (ip.isBlank() || ip.any { !(it.isDigit() || it == '.') }) { toast("Camera IP မှန်ကန်စွာ ထည့်ပါ"); return }
        Thread {
            val ok = runCatching {
                val ready = HttpClient.get("http://$ip:8787/status").toString(Charsets.UTF_8).contains("READY")
                if (ready) HttpClient.get("http://$ip:8787/connect")
                ready
            }.getOrDefault(false)
            runOnUiThread { if (ok) remote(ip) else toast("မချိတ်ဆက်နိုင်ပါ။ Hotspot နဲ့ IP ကို စစ်ပါ။") }
        }.start()
    }

    private fun handleScannedQr(contents: String?) {
        if (contents.isNullOrBlank()) { toast("QR Scan ကို ပယ်ဖျက်လိုက်ပါတယ်"); return }
        val parts = contents.split("|")
        when {
            parts.size == 4 && parts[0] == "KCHO_REMOTE" && parts[1] == "HTTP" && parts[3] == "8787" -> connectHttp(parts[2])
            parts.size == 4 && parts[0] == "KCHO_REMOTE" && parts[1] == "BT" && parts[3] == BluetoothTransport.SERVICE_UUID.toString() -> {
                val name = runCatching { String(Base64.decode(parts[2], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8) }.getOrNull()
                if (!name.isNullOrBlank()) connectBluetooth(name) else toast("Bluetooth QR အချက်အလက် မမှန်ပါ")
            }
            else -> toast("K'Cho RemoteCamera QR မဟုတ်ပါ")
        }
    }

    private fun makeQr(contents: String): Bitmap? = runCatching {
        val size = 600
        val matrix = QRCodeWriter().encode(contents, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size) { index ->
            val x = index % size
            val y = index / size
            if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
        Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565).also { it.setPixels(pixels, 0, size, 0, 0, size, size) }
    }.getOrNull()

    private fun connectBluetooth(deviceName: String) {
        val required = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (required.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            pendingBluetoothName = deviceName
            bluetoothPermissionRequest.launch(required); return
        }
        findBluetoothDevice(deviceName)
    }

    private fun findBluetoothDevice(deviceName: String) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("ဒီဖုန်းတွင် Bluetooth မပါဝင်ပါ"); return }
        if (!adapter.isEnabled) { pendingBluetoothName = deviceName; bluetoothEnableRequest.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        val paired = runCatching { adapter.bondedDevices.firstOrNull { it.name == deviceName } }.getOrNull()
        if (paired != null) { connectBluetoothAddress(paired.address); return }
        pendingBluetoothName = deviceName
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                    runCatching { unregisterReceiver(this) }
                    bluetoothDiscoveryReceiver = null
                    pendingBluetoothName = null
                    toast("Camera ဖုန်း မတွေ့ပါ။ Bluetooth QR ကို ပြန်စစ်ပါ။")
                    return
                }
                if (intent?.action != BluetoothDevice.ACTION_FOUND) return
                @Suppress("DEPRECATION")
                val found = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                if (found != null && found.name == pendingBluetoothName) {
                    runCatching { adapter.cancelDiscovery() }
                    runCatching { unregisterReceiver(this) }
                    bluetoothDiscoveryReceiver = null
                    pendingBluetoothName = null
                    connectBluetoothAddress(found.address)
                }
            }
        }
        bluetoothDiscoveryReceiver = receiver
        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND).apply { addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED) }
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED) else registerReceiver(receiver, filter)
            val started = adapter.isDiscovering || adapter.startDiscovery()
            if (!started) error("Bluetooth discovery စတင်မရပါ")
        }.onFailure {
            bluetoothDiscoveryReceiver?.let { receiverRef -> runCatching { unregisterReceiver(receiverRef) } }
            bluetoothDiscoveryReceiver = null
            pendingBluetoothName = null
            toast("Bluetooth ဖုန်းရှာမရပါ: ${it.message}")
        }
        Toast.makeText(this, "Camera ဖုန်း Bluetooth ကို ရှာနေပါတယ်…", Toast.LENGTH_LONG).show()
    }

    private fun connectBluetoothAddress(address: String) {
        Thread {
            runCatching { BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery() }
            val ok = runCatching { BluetoothTransport.connect(address) == "CONNECTED" }.getOrDefault(false)
            runOnUiThread { if (ok) remote("bt://$address") else toast("Bluetooth မချိတ်ဆက်နိုင်ပါ။ Pairing ကို အတည်ပြုပါ။") }
        }.start()
    }

    private fun remoteCall(target: String, command: String): String {
        return if (target.startsWith("bt://")) {
            val cmd = when (command) {
                "connection" -> "CONNECTION"; "state" -> "STATE"; "capture" -> "CAPTURE"
                "video/toggle" -> "VIDEO_TOGGLE"; "mode/photo" -> "PHOTO_MODE"; "disconnect" -> "DISCONNECT"
                else -> command.uppercase().replace('/', '_')
            }
            if (cmd == "DISCONNECT") { BluetoothTransport.disconnect(); "DISCONNECTED" }
            else BluetoothTransport.send(cmd)
        } else HttpClient.get("http://$target:8787/$command").toString(Charsets.UTF_8)
    }

    private fun remote(ip: String) {
        linkAvailable = true
        enableFloatingControls(ip)
        stopPoller(); root.removeAllViews(); currentMode = "PHOTO"; header("REMOTE CONTROLLER")
        val status = statusCard("CONNECTED", "Camera phone • $ip", GREEN); root.addView(status)
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            val link = runCatching { remoteCall(ip, "connection") }.getOrDefault("DISCONNECTED")
            if (link != "CONNECTED") linkAvailable = false
            val ok = link == "CONNECTED" && linkAvailable
            runOnUiThread { updateStatus(status, if (ok) "CONNECTED" else "DISCONNECTED", if (ok) "Camera phone • $ip" else "Connection lost • tap RECONNECT", if (ok) GREEN else RED) }
        }, 2, 3, TimeUnit.SECONDS)
        space(10)
        label("PHOTO CONTROL", 13, CYAN, true)
        actionButton("📸  TAKE PHOTO", "Camera ဖုန်းမှာ ဓာတ်ပုံရိုက်ပြီး အဲဒီဖုန်းထဲသိမ်းမယ်", BLUE) { command(ip, "capture") }
        space(8)
        label("VIDEO CONTROL", 13, CYAN, true)
        val videoButton = actionButton("▶  START VIDEO", "ထပ်နှိပ်လျှင် ရိုက်ကူးမှုရပ်ပြီး သိမ်းဆည်းမယ်", RED) { command(ip, "video/toggle") }
        poller?.scheduleWithFixedDelay({
            if (!linkAvailable) return@scheduleWithFixedDelay
            val state = runCatching { remoteCall(ip, "state") }.getOrDefault("DISCONNECTED")
            runOnUiThread {
                if (state == "RECORDING") {
                    videoButton.getChildAt(0).let { (it as? TextView)?.text = "●  RECORDING VIDEO" }
                    videoButton.background = rounded(0xFF8E2432.toInt(), 18)
                } else if (state == "IDLE") {
                    videoButton.getChildAt(0).let { (it as? TextView)?.text = "▶  START VIDEO" }
                    videoButton.background = rounded(RED, 18)
                }
            }
        }, 1, 1, TimeUnit.SECONDS)
        actionButton("↻  RECONNECT", "Connection ပြတ်သွားပါက ကိုယ်တိုင်ပြန်ချိတ်မယ်", PURPLE) { reconnect(ip) }
        actionButton("📷  BACK TO PHOTO MODE", "Video ရိုက်နေပါက အရင်ရပ်ပြီး Photo Mode ပြန်ထားမယ်", PURPLE) { command(ip, "mode/photo") }
        space(8)
        label("ဓာတ်ပုံ / ဗီဒီယိုဖိုင်များကို Camera ဖုန်းထဲမှာသာ သိမ်းဆည်းပါတယ်။ ဒီဖုန်းကို ဖိုင်မပို့ပါ။", 12, MUTED)
        button("DISCONNECT", "", DARK_BUTTON) {
            linkAvailable = false
            Thread {
                runCatching { remoteCall(ip, "disconnect") }
                runOnUiThread { home() }
            }.start()
        }
    }

    private fun reconnect(target: String) {
        Thread {
            val ok = runCatching {
                if (target.startsWith("bt://")) BluetoothTransport.connect(target.removePrefix("bt://")) == "CONNECTED"
                else {
                    HttpClient.get("http://$target:8787/status").toString(Charsets.UTF_8).contains("READY") &&
                        HttpClient.get("http://$target:8787/connect").toString(Charsets.UTF_8).contains("CONNECTED")
                }
            }.getOrDefault(false)
            runOnUiThread {
                if (ok) {
                    linkAvailable = true
                    stopService(Intent(this, OverlayControllerService::class.java))
                    enableFloatingControls(target)
                    toast("ပြန်လည်ချိတ်ဆက်ပြီးပါပြီ")
                } else toast("ပြန်ချိတ်ဆက်မရပါ။ Bluetooth / Hotspot ကို စစ်ပါ။")
            }
        }.start()
    }

    private fun enableFloatingControls(ip: String) {
        pendingOverlayIp = ip
        if (Settings.canDrawOverlays(this)) startOverlayService(ip)
        else {
            toast("Floating Popup အတွက် Permission တစ်ကြိမ်ဖွင့်ပေးပါ")
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun startOverlayService(ip: String) {
        pendingOverlayIp = ip
        val intent = Intent(this, OverlayControllerService::class.java).putExtra(OverlayControllerService.EXTRA_IP, ip)
        if (android.os.Build.VERSION.SDK_INT >= 26) androidx.core.content.ContextCompat.startForegroundService(this, intent)
        else startService(intent)
        toast("Floating Popup ဖွင့်ပြီးပါပြီ")
    }

    private fun command(ip: String, cmd: String) {
        if (!linkAvailable) { toast("Connection ပြတ်နေပါတယ်။ RECONNECT ကိုနှိပ်ပါ"); return }
        Thread {
            val ok = runCatching { remoteCall(ip, cmd); true }.getOrDefault(false)
            if (!ok) linkAvailable = false
            runOnUiThread { toast(if (ok) "Command sent" else "ချိတ်ဆက်မှု ပြတ်တောက်နေပါတယ်။ RECONNECT လုပ်ပါ") }
        }.start()
    }

    private fun header(sub: String) {
        label("K'Cho", 30, Color.WHITE, true)
        label("RemoteCamera", 22, CYAN, true)
        label(sub, 11, MUTED, true)
        val line = View(this).apply { background = rounded(0xFF20334F.toInt(), 2) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(2))); space(14)
    }
    private fun card(content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(PANEL, 18); content() }
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
    private fun actionButton(title: String, desc: String, color: Int, action: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(17), dp(18), dp(17)); background = rounded(color, 18)
            isClickable = true; isFocusable = true; elevation = dp(3).toFloat(); setOnClickListener { action() }
        }
        box.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.BOLD) })
        box.addView(TextView(this).apply { text = desc; textSize = 12f; setTextColor(0xFFE5EDFA.toInt()); setPadding(0, dp(5), 0, 0) })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
        return box
    }
    private fun button(title: String, desc: String, color: Int, action: () -> Unit) = actionButton(title, desc, color, action)
    private fun statusCard(t: String, d: String, c: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(PANEL, 16)
        addView(TextView(this@MainActivity).apply { text = "●  $t"; textSize = 16f; setTextColor(c); tag = "t"; typeface = Typeface.DEFAULT_BOLD })
        addView(TextView(this@MainActivity).apply { text = d; textSize = 12f; setTextColor(MUTED); tag = "d"; setPadding(0, dp(6), 0, 0) })
    }
    private fun updateStatus(v: LinearLayout, t: String, d: String, c: Int) {
        v.findViewWithTag<TextView>("t")?.apply { text = "●  $t"; setTextColor(c) }
        v.findViewWithTag<TextView>("d")?.text = d
    }
    private fun info(k: String, v: String) {
        card { label(k, 10, MUTED, true); label(v, 18, Color.WHITE, true) }
    }
    private fun label(s: String, sz: Int, c: Int, b: Boolean = false) {
        root.addView(TextView(this).apply { text = s; textSize = sz.toFloat(); setTextColor(c); if (b) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(6)) })
    }
    private fun space(n: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(n))) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hotspotGateway(): String {
        return try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val raw = wifi.dhcpInfo?.gateway ?: 0
            if (raw == 0) "192.168.43.1" else listOf(raw and 0xff, raw shr 8 and 0xff, raw shr 16 and 0xff, raw shr 24 and 0xff).joinToString(".")
        } catch (_: Exception) { "192.168.43.1" }
    }
    private fun localIp(): String {
        try {
            val ns = NetworkInterface.getNetworkInterfaces()
            while (ns.hasMoreElements()) { val addrs = ns.nextElement().inetAddresses
                while (addrs.hasMoreElements()) { val a = addrs.nextElement(); val ip = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && a is Inet4Address && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) return ip
                }
            }
        } catch (_: Exception) { }
        return "IP မတွေ့ပါ - Hotspot စစ်ပါ"
    }
    private fun stopPoller() { poller?.shutdownNow(); poller = null }
    private fun stopEverything() {
        stopPoller()
        cameraService?.setListener(null)
        if (cameraServiceBound) { runCatching { unbindService(cameraConnection) }; cameraServiceBound = false }
        cameraService = null
    }
    private fun stopBluetoothDiscovery() {
        runCatching { BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery() }
        bluetoothDiscoveryReceiver?.let { runCatching { unregisterReceiver(it) } }
        bluetoothDiscoveryReceiver = null
        pendingBluetoothName = null
    }

    override fun onDestroy() {
        stopBluetoothDiscovery()
        stopEverything(); super.onDestroy()
    }

    companion object {
        private val BG = 0xFF080D18.toInt()
        private val PANEL = 0xFF142238.toInt()
        private val MUTED = 0xFFAAB9CE.toInt()
        private val CYAN = 0xFF42D7FF.toInt()
        private val BLUE = 0xFF1769D2.toInt()
        private val PURPLE = 0xFF6846C8.toInt()
        private val RED = 0xFFC93648.toInt()
        private val AMBER = 0xFFAA6B16.toInt()
        private val GREEN = 0xFF20C982.toInt()
        private val DARK_BUTTON = 0xFF29384D.toInt()
    }
}
