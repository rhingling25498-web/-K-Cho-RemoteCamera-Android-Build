package com.example.remotecamera

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/** Persistent RFCOMM command channel. Link state is cleared only when the socket closes
 * or the user explicitly disconnects; no heartbeat timer or idle timeout is used. */
object BluetoothTransport {
    val SERVICE_UUID: UUID = UUID.fromString("8d3a7f20-6c41-4e8f-a3b2-7d9c51e64021")
    private val connected = AtomicBoolean(false)
    private val clientLock = Any()
    private var clientSocket: BluetoothSocket? = null
    private var clientReader: BufferedReader? = null
    private var clientWriter: PrintWriter? = null
    @Volatile private var activeRemote: BluetoothSocket? = null

    fun resetConnection() {
        connected.set(false)
        runCatching { activeRemote?.close() }
        activeRemote = null
        closeClient()
    }

    fun startServer(adapter: BluetoothAdapter, onCommand: (String) -> String): BluetoothServerSocket {
        connected.set(false)
        val server = adapter.listenUsingRfcommWithServiceRecord("KCho RemoteCamera", SERVICE_UUID)
        Thread({
            while (!Thread.currentThread().isInterrupted) {
                val remote = try { server.accept() } catch (_: Exception) { break }
                activeRemote = remote
                remote.use { socket ->
                    try {
                        val reader = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8))
                        val writer = PrintWriter(socket.outputStream, true)
                        var sessionActive = false
                        while (true) {
                            val request = reader.readLine()?.trim() ?: break
                            val response = when (request) {
                                "CONNECT" -> {
                                    sessionActive = connected.compareAndSet(false, true)
                                    if (sessionActive) "CONNECTED" else "BUSY"
                                }
                                "DISCONNECT" -> { connected.set(false); sessionActive = false; "DISCONNECTED" }
                                "CONNECTION" -> if (connected.get() && sessionActive) "CONNECTED" else "DISCONNECTED"
                                "STATE" -> if (connected.get() && sessionActive) onCommand("STATE") else "NOT_CONNECTED"
                                else -> if (connected.get() && sessionActive) onCommand(request) else "NOT_CONNECTED"
                            }
                            writer.println(response)
                            if (request == "DISCONNECT") break
                        }
                    } catch (_: Exception) {
                    } finally {
                        connected.set(false)
                        activeRemote = null
                    }
                }
            }
        }, "KCho-BT-Acceptor").start()
        return server
    }

    fun connect(address: String): String = synchronized(clientLock) {
        closeClientLocked()
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth မရှိပါ")
        val device = adapter.getRemoteDevice(address)
        val socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
        try {
            socket.connect()
            clientSocket = socket
            clientReader = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8))
            clientWriter = PrintWriter(socket.outputStream, true)
            val response = sendLocked("CONNECT")
            if (response != "CONNECTED") closeClientLocked()
            response
        } catch (e: Exception) {
            runCatching { socket.close() }
            closeClientLocked()
            throw e
        }
    }

    fun send(command: String): String = synchronized(clientLock) {
        sendLocked(command)
    }

    private fun sendLocked(command: String): String {
        val socket = clientSocket ?: error("Bluetooth ချိတ်ဆက်မှု မရှိပါ")
        if (!socket.isConnected) { closeClientLocked(); error("Bluetooth ချိတ်ဆက်မှု ပြတ်တောက်နေပါတယ်") }
        return try {
            clientWriter?.println(command) ?: error("Bluetooth output မရပါ")
            clientReader?.readLine() ?: run { closeClientLocked(); error("Bluetooth response မရပါ") }
        } catch (e: Exception) {
            closeClientLocked()
            throw e
        }
    }

    fun disconnect() {
        synchronized(clientLock) {
            runCatching { if (clientSocket?.isConnected == true) sendLocked("DISCONNECT") }
            closeClientLocked()
        }
    }

    private fun closeClient() = synchronized(clientLock) { closeClientLocked() }

    private fun closeClientLocked() {
        runCatching { clientSocket?.close() }
        clientSocket = null
        clientReader = null
        clientWriter = null
    }
}
