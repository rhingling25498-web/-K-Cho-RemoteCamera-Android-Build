package com.example.remotecamera

import java.net.HttpURLConnection
import java.net.URL

object HttpClient {
    fun get(address: String): ByteArray {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 1800
            readTimeout = 2500
            requestMethod = "GET"
        }
        return try { connection.inputStream.use { it.readBytes() } }
        finally { connection.disconnect() }
    }
}
