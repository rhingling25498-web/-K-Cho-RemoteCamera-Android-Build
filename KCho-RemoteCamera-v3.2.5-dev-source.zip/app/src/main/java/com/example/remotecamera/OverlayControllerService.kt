package com.example.remotecamera

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Floating remote controls remain visible while the user uses another app. */
class OverlayControllerService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var videoLabel: TextView? = null
    private var ip: String = ""
    private val worker = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var recording = false
    @Volatile private var linkAvailable = true
    @Volatile private var pollingStarted = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ip = intent?.getStringExtra(EXTRA_IP) ?: ip
        if (ip.isBlank()) { stopSelf(); return START_NOT_STICKY }
        startForeground(NOTIFICATION_ID, notification())
        linkAvailable = true
        if (panel == null) showPanel()
        if (!pollingStarted) { pollingStarted = true; worker.scheduleWithFixedDelay({ refreshState() }, 0, 1, TimeUnit.SECONDS) }
        return START_STICKY
    }

    private fun showPanel() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = rounded(0xF0142238.toInt(), 18)
            elevation = dp(12).toFloat()
        }
        val handle = TextView(this).apply {
            text = "K'Cho RemoteCamera   ⋮⋮"
            textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10))
        }
        wrap.addView(handle, LinearLayout.LayoutParams(-1, -2))
        val photo = control("PHOTO", 0xFF1769D2.toInt()) { send("capture") }
        wrap.addView(photo, rowParams())
        val videoControl = control("START VIDEO", 0xFFC93648.toInt()) { send("video/toggle") }
        videoLabel = videoControl
        wrap.addView(videoControl, rowParams())
        val disconnect = control("DISCONNECT", 0xFF29384D.toInt()) { disconnect() }
        wrap.addView(disconnect, rowParams())

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(dp(220), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12); y = dp(110)
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX - (event.rawX - touchX).toInt(); params.y = startY + (event.rawY - touchY).toInt(); wm.updateViewLayout(wrap, params); true }
                else -> true
            }
        }
        panel = wrap
        runCatching { wm.addView(wrap, params) }.onFailure { panel = null; stopSelf() }
    }

    private fun control(title: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); setPadding(dp(8), dp(13), dp(8), dp(13)); background = rounded(color, 12)
        isClickable = true; setOnClickListener { action() }
    }

    private fun rowParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

    private fun send(path: String) {
        if (!linkAvailable) { Toast.makeText(this, "Connection ပြတ်နေပါတယ်။ App ထဲက RECONNECT ကိုနှိပ်ပါ", Toast.LENGTH_SHORT).show(); return }
        val target = ip
        Thread {
            val ok = runCatching { remoteCall(target, path); true }.getOrDefault(false)
            if (!ok) {
                linkAvailable = false
                android.os.Handler(mainLooper).post { Toast.makeText(this, "ချိတ်ဆက်မှု ပြတ်တောက်နေပါတယ်။ App ထဲက RECONNECT ကိုနှိပ်ပါ", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun refreshState() {
        val connection = runCatching { remoteCall(ip, "connection") }.getOrDefault("DISCONNECTED")
        if (connection != "CONNECTED") { linkAvailable = false; return }
        if (!linkAvailable) return
        val state = runCatching { remoteCall(ip, "state") }.getOrDefault("DISCONNECTED")
        if (state != "RECORDING" && state != "IDLE") { linkAvailable = false; return }
        recording = state == "RECORDING"
        android.os.Handler(mainLooper).post {
            videoLabel?.apply {
                text = if (recording) "RECORDING VIDEO" else "START VIDEO"
                background = rounded(if (recording) 0xFF8E2432.toInt() else 0xFFC93648.toInt(), 12)
            }
        }
    }

    private fun remoteCall(target: String, path: String): String {
        if (!target.startsWith("bt://")) return HttpClient.get("http://$target:8787/$path").toString(Charsets.UTF_8)
        val command = when (path) {
            "connection" -> "CONNECTION"; "state" -> "STATE"; "capture" -> "CAPTURE"
            "video/toggle" -> "VIDEO_TOGGLE"; "disconnect" -> "DISCONNECT"
            else -> path.uppercase().replace('/', '_')
        }
        return if (command == "DISCONNECT") { BluetoothTransport.disconnect(); "DISCONNECTED" } else BluetoothTransport.send(command)
    }

    private fun disconnect() {
        // Disconnect only this controller. The camera phone keeps its camera/server alive
        // so it can accept a later controller connection.
        val target = ip
        worker.execute {
            runCatching { remoteCall(target, "disconnect") }
            android.os.Handler(mainLooper).post { stopSelf() }
        }
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_camera)
        .setContentTitle("K'Cho RemoteCamera ချိတ်ဆက်ထားသည်")
        .setContentText("Floating PHOTO / VIDEO controls အသင့်ရှိသည်")
        .setOngoing(true).build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Remote camera controls", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        pollingStarted = false
        worker.shutdownNow()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_IP = "camera_ip"
        const val CHANNEL_ID = "kcho_remote_overlay"
        const val NOTIFICATION_ID = 731
    }
}
