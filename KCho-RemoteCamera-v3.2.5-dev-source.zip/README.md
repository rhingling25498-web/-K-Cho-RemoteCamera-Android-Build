# K'Cho RemoteCamera — 2 Phone Edition (source revision 3.2.5-dev)

This is an Android source project. It is not yet a built or physical-device-tested APK.

## Implemented in source
- CameraX photo and video capture run in `CameraForegroundService` and save media on the Camera phone.
- Hotspot/Wi-Fi HTTP control on port 8787.
- QR generation and scanning for Hotspot mode; the QR carries the Camera phone IP and both phones must already be on the same hotspot/network.
- Bluetooth Classic RFCOMM command transport and Bluetooth QR flow. The Camera phone becomes discoverable, the Controller finds it by the Bluetooth device name from the QR, then Android handles pairing confirmation.
- Explicit connection state. If a transport fails, controller commands are blocked until the user manually chooses RECONNECT; Bluetooth uses a persistent RFCOMM socket and clears the session when that socket closes. There is no heartbeat timeout, warning, or automatic reconnect behavior.
- Video toggle displays `START VIDEO` or `RECORDING VIDEO`; stopping video does not disconnect the phones.
- Floating controller overlay has exactly three action buttons: `PHOTO`, `START VIDEO` / `RECORDING VIDEO`, and `DISCONNECT`.
- Overlay is draggable, runs as a foreground service, and requires Android's Display over other apps permission.

## Connection setup
1. Open Camera Phone mode and wait for `READY`.
2. For Hotspot, enable the Camera phone hotspot, connect the Controller phone to it, then show `HOTSPOT QR`.
3. For Bluetooth, choose `BLUETOOTH QR`, allow Bluetooth discoverability, then scan from the Controller phone and accept Android pairing confirmation if requested.
4. In Controller mode, scan the QR. Grant camera permission for scanning and Display over other apps permission for the floating controls.
5. If the connection actually drops, commands stay blocked until `RECONNECT` is tapped manually.

Hotspot QR shares the Camera phone's local IP and port; it does not include or change the hotspot password.

## Still requiring verification
- A successful Gradle build and physical two-phone tests, including Bluetooth pairing/discovery and Android 12–15 permission behavior.
- Android foreground-service and overlay behavior across device manufacturers.
- Authentication/session security beyond Android Bluetooth pairing and the local hotspot connection.

## Build
Open the project root in Android Studio or push it to the configured GitHub Actions workflow to build `app-debug.apk`.
